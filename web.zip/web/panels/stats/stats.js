import { $, fmtDate, DIFF_NAMES, DIFF_COLORS } from '../../js/core.js';
import { data } from '../../js/app.js';

function renderStats() {
  const all = [];
  for (const n in data.lists) all.push(...data.lists[n].problems);

  $('stTotal').textContent = all.length;
  $('stDone').textContent = all.filter(p => p.date).length;
  $('stLists').textContent = Object.keys(data.lists).length;
  $('stNotes').textContent = all.filter(p => p.note).length;

  const dates = [];
  for (let i = 6; i >= 0; i--) { const dt = new Date(); dt.setDate(dt.getDate() - i); dates.push(fmtDate(dt)); }
  const counts = dates.map(d => all.filter(p => p.date === d).length);
  const colors = ['#e8ecf0','#d0d8e0','#b0c4d4','#8aaccc','#6a8aaa','#4a6a8a','#3a5a7a','#2a4a6a'];
  const textColors = ['#94a3b8','#64748b','#475569','#334155','#fff','#fff','#fff','#fff'];
  let cells = '', labels = '';
  dates.forEach((dt, i) => {
    const cnt = counts[i], idx = Math.min(cnt, colors.length - 1);
    cells += '<div class="heatmap-cell" style="background:' + colors[idx] + ';color:' + textColors[idx] + ';" title="' + dt + ': ' + cnt + '">' + cnt + '</div>';
    labels += '<span>' + dt.slice(5) + '</span>';
  });
  $('stHeatmap').innerHTML = '<div class="heatmap-row">' + cells + '</div><div class="heatmap-labels">' + labels + '</div>';

  const doneByDiff = Array(9).fill(0), pendingByDiff = Array(9).fill(0);
  all.forEach(p => { const d = p.difficulty || 0; if (p.date) doneByDiff[d]++; else pendingByDiff[d]++; });
  const maxTotal = Math.max(1, ...doneByDiff.map((c, i) => c + pendingByDiff[i]));
  $('stDiffList').innerHTML = Array.from({ length: 9 }, (_, i) => {
    const dd = doneByDiff[i], pd = pendingByDiff[i], tot = dd + pd;
    if (!tot) return '';
    return '<div class="diff-stat-row">' +
      '<span class="lbl">' + DIFF_NAMES[i] + '</span>' +
      '<div class="bar">' +
        '<span class="done-seg" style="width:' + (dd / maxTotal * 100) + '%;background:' + DIFF_COLORS[i] + ';"></span>' +
        '<span class="pending-seg" style="width:' + (pd / maxTotal * 100) + '%;background:' + DIFF_COLORS[i] + ';"></span>' +
      '</div>' +
      '<span class="cnt">' + dd + '/' + tot + '</span>' +
    '</div>';
  }).join('');
}

export function init() {
  renderStats();
  window.addEventListener('app:state-changed', renderStats);
}
export function activate() { renderStats(); }