import { $, escapeHtml, showToast, copyText, problemStatus, todayStr, DIFF_NAMES, getProblemUrl } from '../../js/core.js';
import { data, pushUndo, saveData, renderAll } from '../../js/app.js';

let randomScope = 'global';

function updateScopeBtns() {
  document.querySelectorAll('#randomScopeToggle button').forEach(b => b.classList.toggle('active', b.dataset.scope === randomScope));
}

function randomPick() {
  const minD = parseInt($('randomDiffMin').value, 10);
  const maxD = parseInt($('randomDiffMax').value, 10);
  let pool = [];
  const addPool = (name, arr) => {
    arr.forEach(p => { if (p.difficulty >= minD && p.difficulty <= maxD && !p.date) pool.push({ pid:p.pid, name:p.name, difficulty:p.difficulty, listName:name }); });
  };
  if (randomScope === 'current') {
    if (!data.currentList) { showToast('请先选择题单', 'warning'); return; }
    addPool(data.currentList, data.lists[data.currentList].problems);
  } else if (randomScope === 'marked') {
    if (!data.markedLists.length) { showToast('请先在侧栏标记题单', 'warning'); return; }
    data.markedLists.forEach(n => { if (data.lists[n]) addPool(n, data.lists[n].problems); });
  } else {
    for (const n in data.lists) addPool(n, data.lists[n].problems);
  }
  if (!pool.length) { $('randomResult').innerHTML = '<div class="random-empty">当前范围内没有未做题目</div>'; return; }
  for (let i = pool.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [pool[i], pool[j]] = [pool[j], pool[i]]; }
  const picked = pool.slice(0, 5);
  $('randomResult').innerHTML = picked.map(p =>
    '<div class="problem-item" style="border:1.5px solid var(--border-subtle);background:var(--surface);" data-rand-pid="' + escapeHtml(p.pid) + '" data-rand-list="' + escapeHtml(p.listName) + '">' +
      '<div class="pi-row">' +
        '<span class="pi-dot-cell"><span class="pi-dot" data-rand-dot="1"></span></span>' +
        '<span class="pi-pid">' + escapeHtml(p.pid) + '</span>' +
        '<span class="pi-name">' + escapeHtml(p.name || '未知题目') + '</span>' +
        '<div class="pi-diff diff-' + (p.difficulty || 0) + '" style="pointer-events:none;min-width:auto;padding:0 10px;font-size:.86em;">' + DIFF_NAMES[p.difficulty || 0] + '</div>' +
        '<span style="font-size:.79em;color:var(--text-muted);flex-shrink:0;">' + escapeHtml(p.listName) + '</span>' +
      '</div>' +
    '</div>').join('');
  $('randomGoLabel').textContent = '换一批';
  $('randomResult').querySelectorAll('.problem-item').forEach(item => {
    item.addEventListener('click', e => {
      if (e.target.closest('.pi-dot')) {
        const pid = item.dataset.randPid, ln = item.dataset.randList;
        const l = data.lists[ln]; if (!l) return;
        const p = l.problems.find(x => x.pid === pid); if (!p) return;
        pushUndo();
        const dot = item.querySelector('.pi-dot');
        const cur = problemStatus(p);
        if (cur === 'pending') { p.date = todayStr(); p.know = false; dot.classList.remove('know'); dot.classList.add('done'); }
        else if (cur === 'done') { p.date = ''; p.know = true; dot.classList.remove('done'); dot.classList.add('know'); }
        else { p.date = ''; p.know = false; dot.classList.remove('done', 'know'); }
        saveData(); renderAll();
      }
    });
    item.addEventListener('contextmenu', e => {
      if (e.target.closest('.pi-pid')) { e.preventDefault(); const url = getProblemUrl(item.dataset.randPid); if (url && url !== '#') window.open(url, '_blank'); }
    });
    item.addEventListener('dblclick', e => {
      if (e.target.closest('.pi-pid')) { copyText(item.dataset.randPid); e.stopPropagation(); return; }
      if (e.target.closest('.pi-name')) {
        const l = data.lists[item.dataset.randList];
        const p = l && l.problems.find(x => x.pid === item.dataset.randPid);
        if (p) copyText(p.name || '');
        e.stopPropagation();
      }
    });
  });
}

export function init(panelEl) {
  panelEl.querySelector('#randomGoBtn').addEventListener('click', randomPick);
  panelEl.querySelector('#randomScopeToggle').addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.scope === randomScope) return;
    randomScope = b.dataset.scope;
    updateScopeBtns();
    $('randomResult').innerHTML = '<div class="random-empty">点击「随机」抽取 5 道未做题目</div>';
    $('randomGoLabel').textContent = '随机';
  });
  updateScopeBtns();
}
export function activate() {}