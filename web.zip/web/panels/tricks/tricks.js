// panels/tricks/tricks.js —— Trick 库：流程图卡片 + 颜色/优先级编辑
import { escapeHtml, showToast, confirmDialog, hexToRgba } from '../../js/core.js';
import { renderMarkdown, renderInlineMultiline } from '../../js/features/markdown.js';
import { onCodexChange, sortedTricks, saveTrick, deleteTrick, TRICK_SWATCHES } from '../../js/features/codex-store.js';

let host = null;
let editingId = null;
let pickingColor = '#5a8a9a';

/** 用 KaTeX 渲染内容里的 $...$ / $$...$$ 公式（KaTeX 由本地 vendor 提供） */
function typesetMath(root) {
  if (!root || typeof window.renderMathInElement !== 'function') return;
  try {
    window.renderMathInElement(root, {
      delimiters: [
        { left: '$$', right: '$$', display: true },
        { left: '$', right: '$', display: false },
        { left: '\\[', right: '\\]', display: true },
        { left: '\\(', right: '\\)', display: false }
      ],
      throwOnError: false,
      ignoredTags: ['script', 'noscript', 'style', 'textarea', 'pre', 'code', 'option']
    });
  } catch (e) { console.warn('[katex]', e); }
}

/* ============================================================
   列表渲染
   ============================================================ */
function nodeHTML(label, text, cls) {
  const empty = !String(text || '').trim();
  return '<div class="tk-node ' + cls + (empty ? ' empty' : '') + '">' +
    '<span class="tk-lbl">' + label + '</span>' +
    '<p class="tk-txt' + (empty ? '' : ' tk-md-inline') + '">' + (empty ? '—' : renderInlineMultiline(text)) + '</p>' +
  '</div>';
}

function cardHTML(t, index) {
  const color = t.color || '#5a8a9a';
  const note = String(t.note || '').trim();
  return '<article class="tk-card" data-tid="' + t.id + '" style="' +
      '--tk:' + color + ';' +
      '--tk-soft:' + hexToRgba(color, 0.10) + ';' +
      '--tk-line:' + hexToRgba(color, 0.42) + ';' +
      '--tk-glow:' + hexToRgba(color, 0.22) + ';" title="点击编辑这条 Trick">' +
    '<div class="tk-prio" title="优先级 ' + (t.priority || 1) + '"><span>P</span><b>' + (t.priority || 1) + '</b></div>' +
    '<div class="tk-main">' +
      '<div class="tk-flow">' +
        nodeHTML('关键性质', t.feature, 'tk-node-key') +
        '<div class="tk-arrow"><i class="fas fa-arrow-right"></i></div>' +
        nodeHTML('转化点', t.transform, 'tk-node-trans') +
        '<div class="tk-arrow"><i class="fas fa-arrow-right"></i></div>' +
        nodeHTML('相关算法', t.algo, 'tk-node-algo') +
      '</div>' +
      (note ? '<div class="tk-note"><i class="fas fa-quote-left"></i><div class="tk-md">' + renderMarkdown(note) + '</div></div>' : '') +
    '</div>' +
    '<div class="tk-actions">' +
      '<button class="tk-act" data-tk-edit title="编辑"><i class="fas fa-pen"></i></button>' +
      '<button class="tk-act danger" data-tk-del title="删除"><i class="fas fa-trash-alt"></i></button>' +
    '</div>' +
  '</article>';
}

function render() {
  if (!host) return;
  const list = host.querySelector('#trickList');
  if (!list) return;
  const all = sortedTricks();
  if (!all.length) {
    list.innerHTML = '<div class="ck-empty">' +
      '<div class="ck-empty-icon"><i class="fas fa-lightbulb"></i></div>' +
      '<h3>Trick 库还是空的</h3>' +
      '<p>把「看到什么性质 → 怎么转化 → 用什么算法」记下来，下次遇到同构题就能秒接。</p>' +
    '</div>';
    return;
  }
  list.innerHTML = '<div class="ck-sect">' +
      '<span class="ck-sect-label"><i class="fas fa-sort-amount-up-alt"></i> 全部 Trick</span>' +
      '<span class="ck-sect-hint">优先级升序 · 同优先级按时间倒序 · 共 ' + all.length + ' 条</span>' +
    '</div>' +
    all.map(cardHTML).join('');

  typesetMath(list);

  list.querySelectorAll('.tk-card').forEach(card => {
    const id = card.dataset.tid;
    card.addEventListener('click', e => {
      const a = e.target.closest('a[href]');
      if (a) {
        e.preventDefault(); e.stopPropagation();
        const href = a.getAttribute('href') || '';
        if (/^https?:\/\//i.test(href)) window.open(href, '_blank');
        return;
      }
      openModal(id);
    });
    const del = card.querySelector('[data-tk-del]');
    if (del) del.addEventListener('click', e => {
      e.stopPropagation();
      const t = sortedTricks().find(x => x.id === id);
      confirmDialog('<i class="fas fa-trash-alt" style="color:var(--danger)"></i> 删除 Trick',
        '删除「<strong>' + escapeHtml((t && t.feature) || '这条 Trick') + '</strong>」？').then(ok => {
        if (!ok) return;
        deleteTrick(id);
        showToast('已删除', 'info');
      });
    });
  });
}

/* ============================================================
   编辑弹窗
   ============================================================ */
function colorRowHTML() {
  return TRICK_SWATCHES.map(c =>
    '<button type="button" class="tk-swatch" data-color="' + c + '" style="--sw:' + c + '" title="' + c + '"></button>'
  ).join('');
}

function syncSwatches() {
  const wrap = document.getElementById('trickSwatches');
  if (!wrap) return;
  if (!wrap.dataset.built) { wrap.innerHTML = colorRowHTML(); wrap.dataset.built = '1'; }
  wrap.querySelectorAll('.tk-swatch').forEach(sw => {
    sw.classList.toggle('active', sw.dataset.color.toLowerCase() === String(pickingColor).toLowerCase());
  });
}

function openModal(id) {
  const modal = document.getElementById('trickModal');
  if (!modal) return;
  const t = id ? sortedTricks().find(x => x.id === id) : null;
  editingId = t ? t.id : null;
  pickingColor = t ? (t.color || '#5a8a9a') : '#5a8a9a';

  document.getElementById('trickModalTitle').textContent = t ? '编辑 Trick' : '添加 Trick';
  document.getElementById('trickKey').value = t ? (t.feature || '') : '';
  document.getElementById('trickTransform').value = t ? (t.transform || '') : '';
  document.getElementById('trickAlgo').value = t ? (t.algo || '') : '';
  document.getElementById('trickNote').value = t ? (t.note || '') : '';
  document.getElementById('trickPriority').value = t ? (t.priority || 1) : 1;
  document.getElementById('trickColor').value = pickingColor;
  syncSwatches();

  modal.classList.add('show');
  setTimeout(() => {
    const el = document.getElementById('trickKey');
    if (el) el.focus();
  }, 160);
}

function save() {
  const feature = document.getElementById('trickKey').value.trim();
  const transform = document.getElementById('trickTransform').value.trim();
  const algo = document.getElementById('trickAlgo').value.trim();
  const note = document.getElementById('trickNote').value;
  const color = document.getElementById('trickColor').value || '#5a8a9a';
  let priority = parseInt(document.getElementById('trickPriority').value, 10);
  if (isNaN(priority) || priority < 1) priority = 1;

  if (!feature) { showToast('关键性质不能为空', 'warning'); document.getElementById('trickKey').focus(); return; }
  if (!algo) { showToast('相关算法不能为空', 'warning'); document.getElementById('trickAlgo').focus(); return; }

  saveTrick(editingId, { feature, transform, algo, note, color, priority });
  document.getElementById('trickModal').classList.remove('show');
  showToast(editingId ? '已更新 Trick' : '已加入 Trick 库', 'success');
  editingId = null;
}

function bindModal() {
  const modal = document.getElementById('trickModal');
  if (!modal || modal._bound) return;
  modal._bound = true;

  const colorInput = document.getElementById('trickColor');
  colorInput.addEventListener('input', () => { pickingColor = colorInput.value; syncSwatches(); });

  const swatches = document.getElementById('trickSwatches');
  swatches.addEventListener('click', e => {
    const sw = e.target.closest('.tk-swatch'); if (!sw) return;
    pickingColor = sw.dataset.color;
    colorInput.value = pickingColor;
    syncSwatches();
  });

  document.getElementById('trickSaveBtn').addEventListener('click', save);
  modal.addEventListener('keydown', e => {
    if (e.key === 'Enter' && e.target.tagName === 'INPUT') { e.preventDefault(); save(); }
  });
}

/* ============================================================
   生命周期
   ============================================================ */
export function init(panelEl) {
  host = panelEl;
  bindModal();
  // 添加按钮已在 #codexHeadActions 中，不在 panel 内
  const addBtn = document.getElementById('trickAddBtn');
  if (addBtn && !addBtn._bound) {
    addBtn._bound = true;
    addBtn.addEventListener('click', () => openModal(null));
  }
  onCodexChange(scope => { if (scope === 'tricks') render(); });
  render();
}

export function activate() { render(); }