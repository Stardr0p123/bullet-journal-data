import { $, escapeHtml, showToast, confirmDialog, openContextMenu, closeModal, hexToRgba } from '../../js/core.js';
import { uid } from '../../js/store.js';
import { themeData, BUILTIN_THEMES, THEME_EDIT_VARS, applyThemeById, saveThemeData, themePalette } from '../../js/features/theme.js';

let editingThemeId = null;

function safeColor(v, fallback) {
  const s = String(v == null ? '' : v).trim();
  if (/^#[0-9a-f]{3,8}$/i.test(s)) return s;
  if (/^rgba?\([\d\s.,%]+\)$/i.test(s)) return s;
  if (/^hsla?\([\d\s.,%deg]+\)$/i.test(s)) return s;
  return fallback;
}
function glowOf(color) {
  return /^#[0-9a-f]{6}$/i.test(String(color || '')) ? hexToRgba(color, 0.34) : 'transparent';
}

function themeCardHTML(t, isCustom) {
  const active = themeData.builtinId === t.id || themeData.customId === t.id;
  const pinned = themeData.pinned.includes(t.id);
  const p = themePalette(t, isCustom);
  const bg = safeColor(p.bg, '#d5dbe3');
  const surface = safeColor(p.surface, '#e6ebf0');
  const text = safeColor(p.text, '#1a2a3a');
  const muted = safeColor(p.muted, '#7a8a9a');
  const primary = safeColor(p.primary, '#5a8a9a');
  const accent = safeColor(p.accent, '#3a6a7a');
  const done = safeColor(p.done, '#61c454');
  const pending = safeColor(p.pending, '#9aa6b0');
  const kind = p.dark ? '深色' : '浅色';
  const style = '--tc-bg:' + bg + ';--tc-surface:' + surface + ';--tc-text:' + text + ';--tc-muted:' + muted +
    ';--tc-primary:' + primary + ';--tc-accent:' + accent + ';--tc-done:' + done + ';--tc-pending:' + pending +
    ';--tc-glow:' + glowOf(primary) + ';';

  const mini =
    '<div class="tc-mini">' +
      '<div class="tc-mini-side">' +
        '<span class="tc-mini-logo"></span>' +
        '<span class="tc-mini-nav active"></span><span class="tc-mini-nav"></span><span class="tc-mini-nav"></span>' +
      '</div>' +
      '<div class="tc-mini-main">' +
        '<div class="tc-mini-top"><span class="tc-mini-title"></span><span class="tc-mini-btn"></span></div>' +
        '<div class="tc-mini-row"><i class="tc-mini-dot" style="background:' + done + '"></i><i class="tc-mini-line" style="width:58%"></i><i class="tc-mini-pill" style="background:' + primary + '"></i></div>' +
        '<div class="tc-mini-row"><i class="tc-mini-dot" style="background:' + pending + '"></i><i class="tc-mini-line" style="width:72%"></i><i class="tc-mini-pill soft"></i></div>' +
        '<div class="tc-mini-row"><i class="tc-mini-dot" style="background:' + done + '"></i><i class="tc-mini-line" style="width:44%"></i><i class="tc-mini-pill" style="background:' + accent + '"></i></div>' +
      '</div>' +
    '</div>';

  return '<article class="theme-card' + (active ? ' active' : '') + (pinned ? ' pinned' : '') + '"' +
      ' data-theme-id="' + escapeHtml(t.id) + '" data-custom="' + (isCustom ? '1' : '0') + '"' +
      ' title="' + (active ? '当前主题' : '点击使用「' + escapeHtml(t.name) + '」') + '">' +
    '<div class="tc-preview" style="' + style + '">' + mini +
      (active ? '<span class="tc-active-badge"><i class="fas fa-check"></i> 已启用</span>' : '') +
      (pinned ? '<span class="tc-pin"><i class="fas fa-thumbtack"></i></span>' : '') +
      '<button class="tc-edit" data-edit="' + escapeHtml(t.id) + '" title="' + (isCustom ? '编辑主题' : '内置主题不可编辑') + '">' +
        (isCustom ? '<i class="fas fa-pen"></i>' : '<i class="fas fa-lock"></i>') + '</button>' +
    '</div>' +
    '<div class="tc-meta">' +
      '<div class="tc-meta-main">' +
        '<span class="tc-name">' + escapeHtml(t.name) + '</span>' +
        '<span class="tc-kind">' + kind + '</span>' +
      '</div>' +
      '<span class="tc-swatches" title="主色 / 背景 / 文字">' +
        '<i style="background:' + primary + '"></i><i style="background:' + bg + '"></i><i style="background:' + text + '"></i>' +
      '</span>' +
    '</div>' +
  '</article>';
}

function renderThemeGrid() {
  const grid = $('themeGrid'); if (!grid) return;
  const all = [
    ...BUILTIN_THEMES.map(t => ({ t, isCustom: false })),
    ...themeData.customThemes.map(t => ({ t, isCustom: true }))
  ];
  all.sort((a, b) => {
    const pa = themeData.pinned.includes(a.t.id) ? 1 : 0;
    const pb = themeData.pinned.includes(b.t.id) ? 1 : 0;
    if (pa !== pb) return pb - pa;
    if (a.isCustom !== b.isCustom) return a.isCustom ? 1 : -1;
    return 0;
  });
  grid.innerHTML = all.map(x => themeCardHTML(x.t, x.isCustom)).join('');

  const count = $('themeCount');
  if (count) count.textContent = BUILTIN_THEMES.length + ' 款内置 · ' + themeData.customThemes.length + ' 款自定义';
  const cur = $('themeCurrent');
  if (cur) {
    const active = all.find(x => themeData.builtinId === x.t.id || themeData.customId === x.t.id);
    cur.textContent = active ? '当前：' + active.t.name : '当前：未选择';
  }
}

function openThemeEditor(id) {
  const t = themeData.customThemes.find(x => x.id === id);
  if (!t) { showToast('内置主题不可编辑', 'info'); return; }
  editingThemeId = id;
  $('editThemeName').textContent = '· ' + t.name;
  $('editThemeTitle').value = t.name;
  const html = document.documentElement;
  const getVar = k => {
    if (t.vars && t.vars[k]) return t.vars[k];
    if (k === 'primary-grad-from') return getComputedStyle(html).getPropertyValue('--primary').trim() || '#5a8a9a';
    if (k === 'primary-grad-to') return getComputedStyle(html).getPropertyValue('--primary-dark').trim() || '#3a6a7a';
    return getComputedStyle(html).getPropertyValue('--' + k).trim();
  };
  $('themeEditorRows').innerHTML = THEME_EDIT_VARS.map(v => {
    const val = getVar(v.key);
    const hex = /^#/.test(val) ? val : '#000000';
    return '<div class="theme-editor-row">' +
      '<label>' + v.name + '</label>' +
      '<input type="color" data-var="' + v.key + '" value="' + escapeHtml(hex) + '" />' +
      '<input type="text" data-var-text="' + v.key + '" value="' + escapeHtml(val) + '" />' +
    '</div>';
  }).join('');
  $('themeEditModal').classList.add('show');
}

function saveThemeEditor() {
  const t = themeData.customThemes.find(x => x.id === editingThemeId);
  if (!t) return;
  const title = $('editThemeTitle').value.trim();
  if (title) t.name = title;
  // 以文本输入为准：颜色选择器无法表示 rgba()，直接读 color input 会把半透明色存成 #000000
  const vars = {};
  $('themeEditorRows').querySelectorAll('input[data-var-text]').forEach(inp => {
    const key = inp.dataset.varText;
    const v = String(inp.value || '').trim();
    if (key && v) vars[key] = v;
  });
  t.vars = vars;
  if (vars['primary-grad-from'] || vars['primary-grad-to']) {
    const f = vars['primary-grad-from'] || '#5a8a9a';
    const to = vars['primary-grad-to'] || '#3a6a7a';
    t.preview = 'linear-gradient(135deg,' + f + ',' + to + ')';
  }
  if (vars.text) t.text = vars.text;
  themeData.customId = t.id; themeData.builtinId = null;
  saveThemeData();
  applyThemeById(t.id, true);
  renderThemeGrid();          // ← 修复：名称 / 预览色变化立即同步到网格
  closeModal('themeEditModal');
  showToast('主题已保存', 'success');
}

function exportTheme(themeId) {
  const t = themeData.customThemes.find(x => x.id === themeId) || BUILTIN_THEMES.find(x => x.id === themeId);
  if (!t) return;
  const isCustom = themeData.customThemes.some(x => x.id === themeId);
  const pack = { version:1, name:t.name, base:isCustom ? (t.base || 'default-light') : themeId, vars:isCustom ? (t.vars || {}) : {} };
  const content = JSON.stringify(pack, null, 2);
  const fileName = '主题_' + t.name + '.json';
  if (window.electronAPI && window.electronAPI.saveFile) {
    window.electronAPI.saveFile(fileName, content).then(r => showToast('已导出 → ' + r.path, 'success')).catch(e => showToast('导出失败：' + e.message, 'error'));
  } else {
    const blob = new Blob([content], { type:'application/json' });
    const u = URL.createObjectURL(blob); const a = document.createElement('a');
    a.href = u; a.download = fileName; a.click(); URL.revokeObjectURL(u);
    showToast('已导出', 'success');
  }
}

function importThemeFile(e) {
  const f = e.target.files[0]; if (!f) return;
  e.target.value = '';
  const reader = new FileReader();
  reader.onload = ev => {
    try {
      const imp = JSON.parse(ev.target.result);
      if (!imp.name) throw new Error('格式错误');
      const id = uid('ct');
      const newT = { id, name:imp.name + ' (导入)', base:imp.base || 'default-light', vars:imp.vars || {}, preview:imp.preview || 'linear-gradient(135deg,#888,#555)', text:imp.text || '#333' };
      themeData.customThemes.push(newT);
      saveThemeData(); renderThemeGrid();
      showToast('已导入主题', 'success');
    } catch (err) { showToast('导入失败：' + err.message, 'error'); }
  };
  reader.readAsText(f);
}

function addCustomTheme() {
  const base = themeData.builtinId || 'default-light';
  const bt = BUILTIN_THEMES.find(x => x.id === base) || BUILTIN_THEMES[0];
  const name = '我的主题 ' + (themeData.customThemes.length + 1);
  const t = { id:uid('ct'), name, base, vars:{ 'primary-grad-from':bt.gradFrom, 'primary-grad-to':bt.gradTo }, preview:bt.preview, text:'#1a2a3a' };
  themeData.customThemes.push(t);
  saveThemeData();
  renderThemeGrid();          // ← 修复：新建后立即渲染网格，新卡片马上出现
  openThemeEditor(t.id);
}

export function init(panelEl) {
  panelEl.querySelector('#themeGrid').addEventListener('click', e => {
    const editBtn = e.target.closest('.tc-edit');
    if (editBtn) {
      e.stopPropagation();
      const id = editBtn.dataset.edit;
      const isCustom = themeData.customThemes.some(x => x.id === id);
      if (!isCustom) { showToast('内置主题不可编辑，可先「添加主题」基于它创建', 'info'); return; }
      openThemeEditor(id); return;
    }
    const card = e.target.closest('.theme-card'); if (!card) return;
    const id = card.dataset.themeId;
    const isCustom = card.dataset.custom === '1';
    applyThemeById(id, isCustom);
    renderThemeGrid();
    showToast('已切换主题', 'success');
  });
  panelEl.querySelector('#themeGrid').addEventListener('contextmenu', e => {
    const card = e.target.closest('.theme-card'); if (!card) return;
    e.preventDefault();
    const id = card.dataset.themeId;
    const isCustom = card.dataset.custom === '1';
    const pinned = themeData.pinned.includes(id);
    const items = [
      { act:'pin', icon:'fa-thumbtack', label:pinned ? '取消置顶' : '置顶', run:() => {
        if (pinned) themeData.pinned = themeData.pinned.filter(x => x !== id);
        else themeData.pinned.push(id);
        saveThemeData(); renderThemeGrid();
      } },
      { act:'export', icon:'fa-download', label:'导出主题', run:() => exportTheme(id) }
    ];
    if (isCustom) {
      items.push({ sep:true });
      items.push({ act:'edit', icon:'fa-pen', label:'编辑主题', run:() => openThemeEditor(id) });
      items.push({ act:'del', icon:'fa-trash-alt', label:'删除主题', danger:true, run:() => {
        confirmDialog('删除主题', '删除自定义主题？').then(ok => {
          if (!ok) return;
          themeData.customThemes = themeData.customThemes.filter(x => x.id !== id);
          themeData.pinned = themeData.pinned.filter(x => x !== id);
          if (themeData.customId === id) { themeData.customId = null; themeData.builtinId = 'default-light'; applyThemeById('default-light', false); }
          saveThemeData(); renderThemeGrid();
        });
      } });
    }
    openContextMenu(e.clientX, e.clientY, items);
  });
  panelEl.querySelector('#importThemeBtn').addEventListener('click', () => $('themeFileInput').click());
  panelEl.querySelector('#themeFileInput').addEventListener('change', importThemeFile);
  panelEl.querySelector('#addThemeBtn').addEventListener('click', addCustomTheme);

  $('themeEditorRows').addEventListener('input', e => {
    if (e.target.dataset.var) {
      const txt = $('themeEditorRows').querySelector('input[data-var-text="' + e.target.dataset.var + '"]');
      if (txt) txt.value = e.target.value;
    } else if (e.target.dataset.varText) {
      const c = $('themeEditorRows').querySelector('input[data-var="' + e.target.dataset.varText + '"]');
      if (c && /^#[0-9a-fA-F]{6}$/.test(e.target.value)) c.value = e.target.value;
    }
  });
  $('themeEditSaveBtn').addEventListener('click', saveThemeEditor);

  renderThemeGrid();
}
export function activate() { renderThemeGrid(); }